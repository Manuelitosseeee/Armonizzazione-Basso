var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

// ../../../../../AppData/Roaming/npm/node_modules/wrangler/node_modules/unenv/dist/runtime/_internal/utils.mjs
// @__NO_SIDE_EFFECTS__
function createNotImplementedError(name) {
  return new Error(`[unenv] ${name} is not implemented yet!`);
}
__name(createNotImplementedError, "createNotImplementedError");
// @__NO_SIDE_EFFECTS__
function notImplemented(name) {
  const fn = /* @__PURE__ */ __name(() => {
    throw /* @__PURE__ */ createNotImplementedError(name);
  }, "fn");
  return Object.assign(fn, { __unenv__: true });
}
__name(notImplemented, "notImplemented");
// @__NO_SIDE_EFFECTS__
function notImplementedClass(name) {
  return class {
    __unenv__ = true;
    constructor() {
      throw new Error(`[unenv] ${name} is not implemented yet!`);
    }
  };
}
__name(notImplementedClass, "notImplementedClass");

// ../../../../../AppData/Roaming/npm/node_modules/wrangler/node_modules/unenv/dist/runtime/node/internal/perf_hooks/performance.mjs
var _timeOrigin = globalThis.performance?.timeOrigin ?? Date.now();
var _performanceNow = globalThis.performance?.now ? globalThis.performance.now.bind(globalThis.performance) : () => Date.now() - _timeOrigin;
var nodeTiming = {
  name: "node",
  entryType: "node",
  startTime: 0,
  duration: 0,
  nodeStart: 0,
  v8Start: 0,
  bootstrapComplete: 0,
  environment: 0,
  loopStart: 0,
  loopExit: 0,
  idleTime: 0,
  uvMetricsInfo: {
    loopCount: 0,
    events: 0,
    eventsWaiting: 0
  },
  detail: void 0,
  toJSON() {
    return this;
  }
};
var PerformanceEntry = class {
  static {
    __name(this, "PerformanceEntry");
  }
  __unenv__ = true;
  detail;
  entryType = "event";
  name;
  startTime;
  constructor(name, options2) {
    this.name = name;
    this.startTime = options2?.startTime || _performanceNow();
    this.detail = options2?.detail;
  }
  get duration() {
    return _performanceNow() - this.startTime;
  }
  toJSON() {
    return {
      name: this.name,
      entryType: this.entryType,
      startTime: this.startTime,
      duration: this.duration,
      detail: this.detail
    };
  }
};
var PerformanceMark = class PerformanceMark2 extends PerformanceEntry {
  static {
    __name(this, "PerformanceMark");
  }
  entryType = "mark";
  constructor() {
    super(...arguments);
  }
  get duration() {
    return 0;
  }
};
var PerformanceMeasure = class extends PerformanceEntry {
  static {
    __name(this, "PerformanceMeasure");
  }
  entryType = "measure";
};
var PerformanceResourceTiming = class extends PerformanceEntry {
  static {
    __name(this, "PerformanceResourceTiming");
  }
  entryType = "resource";
  serverTiming = [];
  connectEnd = 0;
  connectStart = 0;
  decodedBodySize = 0;
  domainLookupEnd = 0;
  domainLookupStart = 0;
  encodedBodySize = 0;
  fetchStart = 0;
  initiatorType = "";
  name = "";
  nextHopProtocol = "";
  redirectEnd = 0;
  redirectStart = 0;
  requestStart = 0;
  responseEnd = 0;
  responseStart = 0;
  secureConnectionStart = 0;
  startTime = 0;
  transferSize = 0;
  workerStart = 0;
  responseStatus = 0;
};
var PerformanceObserverEntryList = class {
  static {
    __name(this, "PerformanceObserverEntryList");
  }
  __unenv__ = true;
  getEntries() {
    return [];
  }
  getEntriesByName(_name, _type) {
    return [];
  }
  getEntriesByType(type) {
    return [];
  }
};
var Performance = class {
  static {
    __name(this, "Performance");
  }
  __unenv__ = true;
  timeOrigin = _timeOrigin;
  eventCounts = /* @__PURE__ */ new Map();
  _entries = [];
  _resourceTimingBufferSize = 0;
  navigation = void 0;
  timing = void 0;
  timerify(_fn, _options) {
    throw createNotImplementedError("Performance.timerify");
  }
  get nodeTiming() {
    return nodeTiming;
  }
  eventLoopUtilization() {
    return {};
  }
  markResourceTiming() {
    return new PerformanceResourceTiming("");
  }
  onresourcetimingbufferfull = null;
  now() {
    if (this.timeOrigin === _timeOrigin) {
      return _performanceNow();
    }
    return Date.now() - this.timeOrigin;
  }
  clearMarks(markName) {
    this._entries = markName ? this._entries.filter((e) => e.name !== markName) : this._entries.filter((e) => e.entryType !== "mark");
  }
  clearMeasures(measureName) {
    this._entries = measureName ? this._entries.filter((e) => e.name !== measureName) : this._entries.filter((e) => e.entryType !== "measure");
  }
  clearResourceTimings() {
    this._entries = this._entries.filter((e) => e.entryType !== "resource" || e.entryType !== "navigation");
  }
  getEntries() {
    return this._entries;
  }
  getEntriesByName(name, type) {
    return this._entries.filter((e) => e.name === name && (!type || e.entryType === type));
  }
  getEntriesByType(type) {
    return this._entries.filter((e) => e.entryType === type);
  }
  mark(name, options2) {
    const entry = new PerformanceMark(name, options2);
    this._entries.push(entry);
    return entry;
  }
  measure(measureName, startOrMeasureOptions, endMark) {
    let start;
    let end;
    if (typeof startOrMeasureOptions === "string") {
      start = this.getEntriesByName(startOrMeasureOptions, "mark")[0]?.startTime;
      end = this.getEntriesByName(endMark, "mark")[0]?.startTime;
    } else {
      start = Number.parseFloat(startOrMeasureOptions?.start) || this.now();
      end = Number.parseFloat(startOrMeasureOptions?.end) || this.now();
    }
    const entry = new PerformanceMeasure(measureName, {
      startTime: start,
      detail: {
        start,
        end
      }
    });
    this._entries.push(entry);
    return entry;
  }
  setResourceTimingBufferSize(maxSize) {
    this._resourceTimingBufferSize = maxSize;
  }
  addEventListener(type, listener, options2) {
    throw createNotImplementedError("Performance.addEventListener");
  }
  removeEventListener(type, listener, options2) {
    throw createNotImplementedError("Performance.removeEventListener");
  }
  dispatchEvent(event) {
    throw createNotImplementedError("Performance.dispatchEvent");
  }
  toJSON() {
    return this;
  }
};
var PerformanceObserver = class {
  static {
    __name(this, "PerformanceObserver");
  }
  __unenv__ = true;
  static supportedEntryTypes = [];
  _callback = null;
  constructor(callback) {
    this._callback = callback;
  }
  takeRecords() {
    return [];
  }
  disconnect() {
    throw createNotImplementedError("PerformanceObserver.disconnect");
  }
  observe(options2) {
    throw createNotImplementedError("PerformanceObserver.observe");
  }
  bind(fn) {
    return fn;
  }
  runInAsyncScope(fn, thisArg, ...args) {
    return fn.call(thisArg, ...args);
  }
  asyncId() {
    return 0;
  }
  triggerAsyncId() {
    return 0;
  }
  emitDestroy() {
    return this;
  }
};
var performance = globalThis.performance && "addEventListener" in globalThis.performance ? globalThis.performance : new Performance();

// ../../../../../AppData/Roaming/npm/node_modules/wrangler/node_modules/@cloudflare/unenv-preset/dist/runtime/polyfill/performance.mjs
if (!("__unenv__" in performance)) {
  const proto = Performance.prototype;
  for (const key of Object.getOwnPropertyNames(proto)) {
    if (key !== "constructor" && !(key in performance)) {
      const desc = Object.getOwnPropertyDescriptor(proto, key);
      if (desc) {
        Object.defineProperty(performance, key, desc);
      }
    }
  }
}
globalThis.performance = performance;
globalThis.Performance = Performance;
globalThis.PerformanceEntry = PerformanceEntry;
globalThis.PerformanceMark = PerformanceMark;
globalThis.PerformanceMeasure = PerformanceMeasure;
globalThis.PerformanceObserver = PerformanceObserver;
globalThis.PerformanceObserverEntryList = PerformanceObserverEntryList;
globalThis.PerformanceResourceTiming = PerformanceResourceTiming;

// ../../../../../AppData/Roaming/npm/node_modules/wrangler/node_modules/unenv/dist/runtime/node/console.mjs
import { Writable } from "node:stream";

// ../../../../../AppData/Roaming/npm/node_modules/wrangler/node_modules/unenv/dist/runtime/mock/noop.mjs
var noop_default = Object.assign(() => {
}, { __unenv__: true });

// ../../../../../AppData/Roaming/npm/node_modules/wrangler/node_modules/unenv/dist/runtime/node/console.mjs
var _console = globalThis.console;
var _ignoreErrors = true;
var _stderr = new Writable();
var _stdout = new Writable();
var log = _console?.log ?? noop_default;
var info = _console?.info ?? log;
var trace = _console?.trace ?? info;
var debug = _console?.debug ?? log;
var table = _console?.table ?? log;
var error = _console?.error ?? log;
var warn = _console?.warn ?? error;
var createTask = _console?.createTask ?? /* @__PURE__ */ notImplemented("console.createTask");
var clear = _console?.clear ?? noop_default;
var count = _console?.count ?? noop_default;
var countReset = _console?.countReset ?? noop_default;
var dir = _console?.dir ?? noop_default;
var dirxml = _console?.dirxml ?? noop_default;
var group = _console?.group ?? noop_default;
var groupEnd = _console?.groupEnd ?? noop_default;
var groupCollapsed = _console?.groupCollapsed ?? noop_default;
var profile = _console?.profile ?? noop_default;
var profileEnd = _console?.profileEnd ?? noop_default;
var time = _console?.time ?? noop_default;
var timeEnd = _console?.timeEnd ?? noop_default;
var timeLog = _console?.timeLog ?? noop_default;
var timeStamp = _console?.timeStamp ?? noop_default;
var Console = _console?.Console ?? /* @__PURE__ */ notImplementedClass("console.Console");
var _times = /* @__PURE__ */ new Map();
var _stdoutErrorHandler = noop_default;
var _stderrErrorHandler = noop_default;

// ../../../../../AppData/Roaming/npm/node_modules/wrangler/node_modules/@cloudflare/unenv-preset/dist/runtime/node/console.mjs
var workerdConsole = globalThis["console"];
var {
  assert,
  clear: clear2,
  // @ts-expect-error undocumented public API
  context,
  count: count2,
  countReset: countReset2,
  // @ts-expect-error undocumented public API
  createTask: createTask2,
  debug: debug2,
  dir: dir2,
  dirxml: dirxml2,
  error: error2,
  group: group2,
  groupCollapsed: groupCollapsed2,
  groupEnd: groupEnd2,
  info: info2,
  log: log2,
  profile: profile2,
  profileEnd: profileEnd2,
  table: table2,
  time: time2,
  timeEnd: timeEnd2,
  timeLog: timeLog2,
  timeStamp: timeStamp2,
  trace: trace2,
  warn: warn2
} = workerdConsole;
Object.assign(workerdConsole, {
  Console,
  _ignoreErrors,
  _stderr,
  _stderrErrorHandler,
  _stdout,
  _stdoutErrorHandler,
  _times
});
var console_default = workerdConsole;

// ../../../../../AppData/Roaming/npm/node_modules/wrangler/_virtual_unenv_global_polyfill-@cloudflare-unenv-preset-node-console
globalThis.console = console_default;

// ../../../../../AppData/Roaming/npm/node_modules/wrangler/node_modules/unenv/dist/runtime/node/internal/process/hrtime.mjs
var hrtime = /* @__PURE__ */ Object.assign(/* @__PURE__ */ __name(function hrtime2(startTime) {
  const now2 = Date.now();
  const seconds = Math.trunc(now2 / 1e3);
  const nanos = now2 % 1e3 * 1e6;
  if (startTime) {
    let diffSeconds = seconds - startTime[0];
    let diffNanos = nanos - startTime[0];
    if (diffNanos < 0) {
      diffSeconds = diffSeconds - 1;
      diffNanos = 1e9 + diffNanos;
    }
    return [diffSeconds, diffNanos];
  }
  return [seconds, nanos];
}, "hrtime"), { bigint: /* @__PURE__ */ __name(function bigint() {
  return BigInt(Date.now() * 1e6);
}, "bigint") });

// ../../../../../AppData/Roaming/npm/node_modules/wrangler/node_modules/unenv/dist/runtime/node/internal/process/process.mjs
import { EventEmitter } from "node:events";

// ../../../../../AppData/Roaming/npm/node_modules/wrangler/node_modules/unenv/dist/runtime/node/internal/tty/read-stream.mjs
var ReadStream = class {
  static {
    __name(this, "ReadStream");
  }
  fd;
  isRaw = false;
  isTTY = false;
  constructor(fd) {
    this.fd = fd;
  }
  setRawMode(mode) {
    this.isRaw = mode;
    return this;
  }
};

// ../../../../../AppData/Roaming/npm/node_modules/wrangler/node_modules/unenv/dist/runtime/node/internal/tty/write-stream.mjs
var WriteStream = class {
  static {
    __name(this, "WriteStream");
  }
  fd;
  columns = 80;
  rows = 24;
  isTTY = false;
  constructor(fd) {
    this.fd = fd;
  }
  clearLine(dir3, callback) {
    callback && callback();
    return false;
  }
  clearScreenDown(callback) {
    callback && callback();
    return false;
  }
  cursorTo(x, y, callback) {
    callback && typeof callback === "function" && callback();
    return false;
  }
  moveCursor(dx, dy, callback) {
    callback && callback();
    return false;
  }
  getColorDepth(env2) {
    return 1;
  }
  hasColors(count3, env2) {
    return false;
  }
  getWindowSize() {
    return [this.columns, this.rows];
  }
  write(str, encoding, cb) {
    if (str instanceof Uint8Array) {
      str = new TextDecoder().decode(str);
    }
    try {
      console.log(str);
    } catch {
    }
    cb && typeof cb === "function" && cb();
    return false;
  }
};

// ../../../../../AppData/Roaming/npm/node_modules/wrangler/node_modules/unenv/dist/runtime/node/internal/process/node-version.mjs
var NODE_VERSION = "22.14.0";

// ../../../../../AppData/Roaming/npm/node_modules/wrangler/node_modules/unenv/dist/runtime/node/internal/process/process.mjs
var Process = class _Process extends EventEmitter {
  static {
    __name(this, "Process");
  }
  env;
  hrtime;
  nextTick;
  constructor(impl) {
    super();
    this.env = impl.env;
    this.hrtime = impl.hrtime;
    this.nextTick = impl.nextTick;
    for (const prop of [...Object.getOwnPropertyNames(_Process.prototype), ...Object.getOwnPropertyNames(EventEmitter.prototype)]) {
      const value = this[prop];
      if (typeof value === "function") {
        this[prop] = value.bind(this);
      }
    }
  }
  // --- event emitter ---
  emitWarning(warning, type, code) {
    console.warn(`${code ? `[${code}] ` : ""}${type ? `${type}: ` : ""}${warning}`);
  }
  emit(...args) {
    return super.emit(...args);
  }
  listeners(eventName) {
    return super.listeners(eventName);
  }
  // --- stdio (lazy initializers) ---
  #stdin;
  #stdout;
  #stderr;
  get stdin() {
    return this.#stdin ??= new ReadStream(0);
  }
  get stdout() {
    return this.#stdout ??= new WriteStream(1);
  }
  get stderr() {
    return this.#stderr ??= new WriteStream(2);
  }
  // --- cwd ---
  #cwd = "/";
  chdir(cwd2) {
    this.#cwd = cwd2;
  }
  cwd() {
    return this.#cwd;
  }
  // --- dummy props and getters ---
  arch = "";
  platform = "";
  argv = [];
  argv0 = "";
  execArgv = [];
  execPath = "";
  title = "";
  pid = 200;
  ppid = 100;
  get version() {
    return `v${NODE_VERSION}`;
  }
  get versions() {
    return { node: NODE_VERSION };
  }
  get allowedNodeEnvironmentFlags() {
    return /* @__PURE__ */ new Set();
  }
  get sourceMapsEnabled() {
    return false;
  }
  get debugPort() {
    return 0;
  }
  get throwDeprecation() {
    return false;
  }
  get traceDeprecation() {
    return false;
  }
  get features() {
    return {};
  }
  get release() {
    return {};
  }
  get connected() {
    return false;
  }
  get config() {
    return {};
  }
  get moduleLoadList() {
    return [];
  }
  constrainedMemory() {
    return 0;
  }
  availableMemory() {
    return 0;
  }
  uptime() {
    return 0;
  }
  resourceUsage() {
    return {};
  }
  // --- noop methods ---
  ref() {
  }
  unref() {
  }
  // --- unimplemented methods ---
  umask() {
    throw createNotImplementedError("process.umask");
  }
  getBuiltinModule() {
    return void 0;
  }
  getActiveResourcesInfo() {
    throw createNotImplementedError("process.getActiveResourcesInfo");
  }
  exit() {
    throw createNotImplementedError("process.exit");
  }
  reallyExit() {
    throw createNotImplementedError("process.reallyExit");
  }
  kill() {
    throw createNotImplementedError("process.kill");
  }
  abort() {
    throw createNotImplementedError("process.abort");
  }
  dlopen() {
    throw createNotImplementedError("process.dlopen");
  }
  setSourceMapsEnabled() {
    throw createNotImplementedError("process.setSourceMapsEnabled");
  }
  loadEnvFile() {
    throw createNotImplementedError("process.loadEnvFile");
  }
  disconnect() {
    throw createNotImplementedError("process.disconnect");
  }
  cpuUsage() {
    throw createNotImplementedError("process.cpuUsage");
  }
  setUncaughtExceptionCaptureCallback() {
    throw createNotImplementedError("process.setUncaughtExceptionCaptureCallback");
  }
  hasUncaughtExceptionCaptureCallback() {
    throw createNotImplementedError("process.hasUncaughtExceptionCaptureCallback");
  }
  initgroups() {
    throw createNotImplementedError("process.initgroups");
  }
  openStdin() {
    throw createNotImplementedError("process.openStdin");
  }
  assert() {
    throw createNotImplementedError("process.assert");
  }
  binding() {
    throw createNotImplementedError("process.binding");
  }
  // --- attached interfaces ---
  permission = { has: /* @__PURE__ */ notImplemented("process.permission.has") };
  report = {
    directory: "",
    filename: "",
    signal: "SIGUSR2",
    compact: false,
    reportOnFatalError: false,
    reportOnSignal: false,
    reportOnUncaughtException: false,
    getReport: /* @__PURE__ */ notImplemented("process.report.getReport"),
    writeReport: /* @__PURE__ */ notImplemented("process.report.writeReport")
  };
  finalization = {
    register: /* @__PURE__ */ notImplemented("process.finalization.register"),
    unregister: /* @__PURE__ */ notImplemented("process.finalization.unregister"),
    registerBeforeExit: /* @__PURE__ */ notImplemented("process.finalization.registerBeforeExit")
  };
  memoryUsage = Object.assign(() => ({
    arrayBuffers: 0,
    rss: 0,
    external: 0,
    heapTotal: 0,
    heapUsed: 0
  }), { rss: /* @__PURE__ */ __name(() => 0, "rss") });
  // --- undefined props ---
  mainModule = void 0;
  domain = void 0;
  // optional
  send = void 0;
  exitCode = void 0;
  channel = void 0;
  getegid = void 0;
  geteuid = void 0;
  getgid = void 0;
  getgroups = void 0;
  getuid = void 0;
  setegid = void 0;
  seteuid = void 0;
  setgid = void 0;
  setgroups = void 0;
  setuid = void 0;
  // internals
  _events = void 0;
  _eventsCount = void 0;
  _exiting = void 0;
  _maxListeners = void 0;
  _debugEnd = void 0;
  _debugProcess = void 0;
  _fatalException = void 0;
  _getActiveHandles = void 0;
  _getActiveRequests = void 0;
  _kill = void 0;
  _preload_modules = void 0;
  _rawDebug = void 0;
  _startProfilerIdleNotifier = void 0;
  _stopProfilerIdleNotifier = void 0;
  _tickCallback = void 0;
  _disconnect = void 0;
  _handleQueue = void 0;
  _pendingMessage = void 0;
  _channel = void 0;
  _send = void 0;
  _linkedBinding = void 0;
};

// ../../../../../AppData/Roaming/npm/node_modules/wrangler/node_modules/@cloudflare/unenv-preset/dist/runtime/node/process.mjs
var globalProcess = globalThis["process"];
var getBuiltinModule = globalProcess.getBuiltinModule;
var workerdProcess = getBuiltinModule("node:process");
var unenvProcess = new Process({
  env: globalProcess.env,
  hrtime,
  // `nextTick` is available from workerd process v1
  nextTick: workerdProcess.nextTick
});
var { exit, features, platform } = workerdProcess;
var {
  _channel,
  _debugEnd,
  _debugProcess,
  _disconnect,
  _events,
  _eventsCount,
  _exiting,
  _fatalException,
  _getActiveHandles,
  _getActiveRequests,
  _handleQueue,
  _kill,
  _linkedBinding,
  _maxListeners,
  _pendingMessage,
  _preload_modules,
  _rawDebug,
  _send,
  _startProfilerIdleNotifier,
  _stopProfilerIdleNotifier,
  _tickCallback,
  abort,
  addListener,
  allowedNodeEnvironmentFlags,
  arch,
  argv,
  argv0,
  assert: assert2,
  availableMemory,
  binding,
  channel,
  chdir,
  config,
  connected,
  constrainedMemory,
  cpuUsage,
  cwd,
  debugPort,
  disconnect,
  dlopen,
  domain,
  emit,
  emitWarning,
  env,
  eventNames,
  execArgv,
  execPath,
  exitCode,
  finalization,
  getActiveResourcesInfo,
  getegid,
  geteuid,
  getgid,
  getgroups,
  getMaxListeners,
  getuid,
  hasUncaughtExceptionCaptureCallback,
  hrtime: hrtime3,
  initgroups,
  kill,
  listenerCount,
  listeners,
  loadEnvFile,
  mainModule,
  memoryUsage,
  moduleLoadList,
  nextTick,
  off,
  on,
  once,
  openStdin,
  permission,
  pid,
  ppid,
  prependListener,
  prependOnceListener,
  rawListeners,
  reallyExit,
  ref,
  release,
  removeAllListeners,
  removeListener,
  report,
  resourceUsage,
  send,
  setegid,
  seteuid,
  setgid,
  setgroups,
  setMaxListeners,
  setSourceMapsEnabled,
  setuid,
  setUncaughtExceptionCaptureCallback,
  sourceMapsEnabled,
  stderr,
  stdin,
  stdout,
  throwDeprecation,
  title,
  traceDeprecation,
  umask,
  unref,
  uptime,
  version,
  versions
} = unenvProcess;
var _process = {
  abort,
  addListener,
  allowedNodeEnvironmentFlags,
  hasUncaughtExceptionCaptureCallback,
  setUncaughtExceptionCaptureCallback,
  loadEnvFile,
  sourceMapsEnabled,
  arch,
  argv,
  argv0,
  chdir,
  config,
  connected,
  constrainedMemory,
  availableMemory,
  cpuUsage,
  cwd,
  debugPort,
  dlopen,
  disconnect,
  emit,
  emitWarning,
  env,
  eventNames,
  execArgv,
  execPath,
  exit,
  finalization,
  features,
  getBuiltinModule,
  getActiveResourcesInfo,
  getMaxListeners,
  hrtime: hrtime3,
  kill,
  listeners,
  listenerCount,
  memoryUsage,
  nextTick,
  on,
  off,
  once,
  pid,
  platform,
  ppid,
  prependListener,
  prependOnceListener,
  rawListeners,
  release,
  removeAllListeners,
  removeListener,
  report,
  resourceUsage,
  setMaxListeners,
  setSourceMapsEnabled,
  stderr,
  stdin,
  stdout,
  title,
  throwDeprecation,
  traceDeprecation,
  umask,
  uptime,
  version,
  versions,
  // @ts-expect-error old API
  domain,
  initgroups,
  moduleLoadList,
  reallyExit,
  openStdin,
  assert: assert2,
  binding,
  send,
  exitCode,
  channel,
  getegid,
  geteuid,
  getgid,
  getgroups,
  getuid,
  setegid,
  seteuid,
  setgid,
  setgroups,
  setuid,
  permission,
  mainModule,
  _events,
  _eventsCount,
  _exiting,
  _maxListeners,
  _debugEnd,
  _debugProcess,
  _fatalException,
  _getActiveHandles,
  _getActiveRequests,
  _kill,
  _preload_modules,
  _rawDebug,
  _startProfilerIdleNotifier,
  _stopProfilerIdleNotifier,
  _tickCallback,
  _disconnect,
  _handleQueue,
  _pendingMessage,
  _channel,
  _send,
  _linkedBinding
};
var process_default = _process;

// ../../../../../AppData/Roaming/npm/node_modules/wrangler/_virtual_unenv_global_polyfill-@cloudflare-unenv-preset-node-process
globalThis.process = process_default;

// _worker.js
var enc = new TextEncoder();
var digest = /* @__PURE__ */ __name(async (s) => Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", enc.encode(s)))).map((n) => n.toString(16).padStart(2, "0")).join(""), "digest");
var token = /* @__PURE__ */ __name(() => Array.from(crypto.getRandomValues(new Uint8Array(32))).map((n) => n.toString(16).padStart(2, "0")).join(""), "token");
var now = /* @__PURE__ */ __name(() => Math.floor(Date.now() / 1e3), "now");
var REMEMBER_SECONDS = 365 * 86400;
var json = /* @__PURE__ */ __name((o, status = 200) => new Response(JSON.stringify(o), { status, headers: { "Content-Type": "application/json; charset=utf-8" } }), "json");
var fail = /* @__PURE__ */ __name((message, status = 400) => {
  throw Object.assign(Error(message), { status });
}, "fail");
var cookie = /* @__PURE__ */ __name((name, value, age) => `${name}=${value}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${age}`, "cookie");
var cookies = /* @__PURE__ */ __name((req) => Object.fromEntries((req.headers.get("cookie") || "").split(";").map((s) => s.trim().split("="))), "cookies");
var stmt = /* @__PURE__ */ __name((env2, sql, ...args) => env2.DB.prepare(sql).bind(...args), "stmt");
function normalizeIP(s) {
  if (typeof s !== "string" || s.length > 64) fail("IP non valido.");
  if (s.includes(":")) {
    try {
      return new URL(`http://[${s}]/`).hostname.slice(1, -1).toLowerCase();
    } catch {
      fail("IP non valido.");
    }
  }
  if (!/^\d{1,3}(\.\d{1,3}){3}$/.test(s) || s.split(".").some((p) => Number(p) > 255 || String(Number(p)) !== p)) fail("IP non valido.");
  return s;
}
__name(normalizeIP, "normalizeIP");
var ipOf = /* @__PURE__ */ __name((req) => normalizeIP(req.headers.get("cf-connecting-ip") || ""), "ipOf");
function options(b) {
  const max_devices = Number(b.max_devices ?? 3), max_sessions = Number(b.max_sessions ?? 3);
  if (!Number.isInteger(max_devices) || max_devices < 1 || max_devices > 100 || !Number.isInteger(max_sessions) || max_sessions < 1 || max_sessions > 100) fail("Limiti: interi da 1 a 100.");
  const ip_mode = b.ip_mode || "any", device_mode = b.device_mode || "any";
  if (!["any", "first", "fixed"].includes(ip_mode) || !["any", "first", "fixed"].includes(device_mode)) fail("Vincolo non valido.");
  const allowed_ip = ip_mode === "fixed" ? normalizeIP(b.allowed_ip) : null, allowed_device = device_mode === "fixed" ? String(b.allowed_device || "") : null;
  if (device_mode === "fixed" && !/^[a-f0-9-]{36}$/.test(allowed_device)) fail("Seleziona un dispositivo gi\xE0 registrato.");
  const expires = b.expires ? Math.floor(new Date(b.expires).getTime() / 1e3) : null;
  if (expires !== null && (!Number.isFinite(expires) || expires < 0)) fail("Scadenza non valida.");
  const label = String(b.label || "Nuova key").trim().slice(0, 100);
  return { label, enabled: b.enabled === false ? 0 : 1, expires, max_devices, max_sessions, ip_mode, allowed_ip, device_mode, allowed_device };
}
__name(options, "options");
async function bounded(req, limit) {
  if (Number(req.headers.get("content-length")) > limit) fail("Richiesta troppo grande.", 413);
  const reader = req.body?.getReader();
  if (!reader) return new Uint8Array();
  const chunks = [];
  let size = 0;
  for (; ; ) {
    const { done, value } = await reader.read();
    if (done) break;
    size += value.byteLength;
    if (size > limit) {
      await reader.cancel();
      fail("Richiesta troppo grande.", 413);
    }
    chunks.push(value);
  }
  const all = new Uint8Array(size);
  let offset = 0;
  for (const c of chunks) {
    all.set(c, offset);
    offset += c.byteLength;
  }
  return all;
}
__name(bounded, "bounded");
async function body(req) {
  const text = new TextDecoder().decode(await bounded(req, 16e3));
  try {
    return JSON.parse(text);
  } catch {
    fail("JSON non valido.");
  }
}
__name(body, "body");
function origin(req) {
  if (req.headers.get("origin") !== new URL(req.url).origin) fail("Origine non autorizzata.", 403);
  if (req.headers.get("sec-fetch-site") === "cross-site") fail("Richiesta non autorizzata.", 403);
}
__name(origin, "origin");
async function validateSession(req, env2) {
  const c = cookies(req);
  if (!/^[a-f0-9]{64}$/.test(c["__Host-ar-session"] || "") || !/^[a-f0-9]{64}$/.test(c["__Host-ar-device"] || "")) return null;
  const s = await stmt(env2, `SELECT s.*,l.enabled AS key_enabled,l.expires AS key_expires,l.ip_mode,l.allowed_ip,l.device_mode,l.allowed_device,d.enabled AS device_enabled,d.proof FROM sessions s JOIN licenses l ON l.id=s.key_id JOIN devices d ON d.id=s.device_id WHERE s.hash=?`, await digest(c["__Host-ar-session"])).first();
  if (!s || s.revoked || !s.key_enabled || !s.device_enabled || s.expires <= now() || s.key_expires && s.key_expires <= now() || s.proof !== await digest(c["__Host-ar-device"])) return null;
  const ip = ipOf(req);
  if (s.ip_mode !== "any" && s.allowed_ip !== ip || s.device_mode !== "any" && s.allowed_device !== s.device_id) return null;
  if (s.expires < now() + REMEMBER_SECONDS - 86400) {
    s.expires = now() + REMEMBER_SECONDS;
    await stmt(env2, "UPDATE sessions SET expires=? WHERE id=? AND revoked=0", s.expires, s.id).run();
    s.refreshCookies = true;
  }
  if (s.seen < now() - 60 || s.ip !== ip) {
    await env2.DB.batch([stmt(env2, "UPDATE sessions SET seen=?,ip=? WHERE id=?", now(), ip, s.id), stmt(env2, "INSERT INTO ip_history VALUES(?,?,?,?) ON CONFLICT(session_id,ip) DO UPDATE SET last_seen=excluded.last_seen", s.id, ip, now(), now())]);
  }
  return s;
}
__name(validateSession, "validateSession");
async function login(req, env2) {
  origin(req);
  const ip = ipOf(req), minute = Math.floor(now() / 60), iph = await digest(ip);
  const rate = await env2.DB.batch([stmt(env2, "INSERT INTO attempts VALUES(?,?,1) ON CONFLICT(ip_hash,minute) DO UPDATE SET count=count+1", iph, minute), stmt(env2, "SELECT count FROM attempts WHERE ip_hash=? AND minute=?", iph, minute), stmt(env2, "DELETE FROM attempts WHERE minute<?", minute - 10)]);
  if (rate[1].results[0].count > 10) fail("Troppi tentativi. Riprova tra un minuto.", 429);
  const b = await body(req), raw = String(b.key || "").trim();
  const k = await stmt(env2, "SELECT * FROM licenses WHERE hash=?", await digest(raw)).first();
  if (!k || !k.enabled || k.expires && k.expires <= now()) fail("Key non valida, sospesa o scaduta.", 403);
  if (k.ip_mode !== "any" && k.allowed_ip && k.allowed_ip !== ip) fail("Questa key \xE8 riservata a un altro IP.", 403);
  const c = cookies(req), proof = /^[a-f0-9]{64}$/.test(c["__Host-ar-device"] || "") ? c["__Host-ar-device"] : token(), proofHash = await digest(proof), device = crypto.randomUUID(), sid = crypto.randomUUID(), secret = token(), ua = (req.headers.get("user-agent") || "Browser").slice(0, 300), t = now();
  await env2.DB.batch([
    stmt(env2, `INSERT INTO devices(id,key_id,proof,label,created) SELECT ?,?,?,?,? WHERE NOT EXISTS(SELECT 1 FROM devices WHERE key_id=? AND proof=?) AND (SELECT COUNT(*) FROM devices WHERE key_id=? AND enabled=1)<(SELECT max_devices FROM licenses WHERE id=?) AND (SELECT device_mode FROM licenses WHERE id=?)!='fixed' AND NOT EXISTS(SELECT 1 FROM licenses WHERE id=? AND device_mode='first' AND allowed_device IS NOT NULL) AND EXISTS(SELECT 1 FROM licenses l WHERE l.id=? AND l.enabled=1 AND (l.expires IS NULL OR l.expires>?) AND (l.ip_mode='any' OR l.allowed_ip IS NULL OR l.allowed_ip=?) AND (SELECT COUNT(*) FROM sessions WHERE key_id=l.id AND revoked=0 AND expires>?)<l.max_sessions)`, device, k.id, proofHash, ua, t, k.id, proofHash, k.id, k.id, k.id, k.id, k.id, t, ip, t),
    stmt(env2, `UPDATE licenses SET allowed_ip=? WHERE id=? AND ip_mode='first' AND allowed_ip IS NULL AND EXISTS(SELECT 1 FROM devices WHERE key_id=? AND proof=? AND enabled=1)`, ip, k.id, k.id, proofHash),
    stmt(env2, `UPDATE licenses SET allowed_device=(SELECT id FROM devices WHERE key_id=? AND proof=? AND enabled=1) WHERE id=? AND device_mode='first' AND allowed_device IS NULL`, k.id, proofHash, k.id),
    stmt(env2, `UPDATE sessions SET revoked=1 WHERE key_id=? AND device_id=(SELECT id FROM devices WHERE key_id=? AND proof=?)`, k.id, k.id, proofHash),
    stmt(env2, `INSERT INTO sessions(id,hash,key_id,device_id,ip,ua,created,seen,expires) SELECT ?,?,?,d.id,?,?,?,?,? FROM devices d JOIN licenses l ON l.id=d.key_id WHERE l.id=? AND d.proof=? AND d.enabled=1 AND l.enabled=1 AND (l.expires IS NULL OR l.expires>?) AND (l.ip_mode='any' OR l.allowed_ip=?) AND (l.device_mode='any' OR l.allowed_device=d.id) AND (SELECT COUNT(*) FROM sessions WHERE key_id=l.id AND revoked=0 AND expires>?)<l.max_sessions`, sid, await digest(secret), k.id, ip, ua, t, t, t + REMEMBER_SECONDS, k.id, proofHash, t, ip, t),
    stmt(env2, `INSERT INTO ip_history SELECT id,ip,created,seen FROM sessions WHERE id=?`, sid)
  ]);
  const added = await stmt(env2, "SELECT id FROM sessions WHERE id=?", sid).first();
  if (!added) fail("Accesso negato: limite di dispositivi/sessioni o dispositivo non autorizzato. Chiedi al proprietario di controllare la key.", 403);
  const r = json({ ok: true });
  r.headers.append("Set-Cookie", cookie("__Host-ar-session", secret, REMEMBER_SECONDS));
  r.headers.append("Set-Cookie", cookie("__Host-ar-device", proof, 365 * 86400));
  return r;
}
__name(login, "login");
var ADMIN_TABLE = "CREATE TABLE IF NOT EXISTS admin_sessions(hash TEXT PRIMARY KEY, actor TEXT NOT NULL, credential TEXT NOT NULL, created INTEGER NOT NULL, expires INTEGER NOT NULL, revoked INTEGER NOT NULL DEFAULT 0)";
var same = /* @__PURE__ */ __name((a, b) => {
  if (a.length !== b.length) return false;
  let difference = 0;
  for (let i = 0; i < a.length; i++) difference |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return difference === 0;
}, "same");
function adminConfigured(env2) {
  if (!env2.ADMIN_EMAIL || typeof env2.ADMIN_PASSWORD !== "string" || env2.ADMIN_PASSWORD.length < 20 || env2.ADMIN_PASSWORD.length > 128) fail("Login amministratore non configurato. Esegui ATTIVA-LOGIN.cmd sul tuo PC.", 503);
}
__name(adminConfigured, "adminConfigured");
async function adminIdentity(req, env2) {
  adminConfigured(env2);
  const raw = cookies(req)["__Host-ar-admin"];
  if (!/^[a-f0-9]{64}$/.test(raw || "")) return null;
  let row;
  try {
    row = await stmt(env2, "SELECT * FROM admin_sessions WHERE hash=?", await digest(raw)).first();
  } catch (e) {
    if (String(e.message).includes("no such table")) return null;
    throw e;
  }
  if (!row || row.revoked || row.expires <= now() || row.actor !== env2.ADMIN_EMAIL.toLowerCase() || !same(row.credential, await digest("admin-v1:" + env2.ADMIN_PASSWORD))) return null;
  return row.actor;
}
__name(adminIdentity, "adminIdentity");
async function adminLogin(req, env2) {
  origin(req);
  adminConfigured(env2);
  const t = now(), minute = Math.floor(t / 60), iph = await digest("admin:" + ipOf(req));
  const rate = await env2.DB.batch([stmt(env2, "INSERT INTO attempts VALUES(?,?,1) ON CONFLICT(ip_hash,minute) DO UPDATE SET count=count+1", iph, minute), stmt(env2, "SELECT count FROM attempts WHERE ip_hash=? AND minute=?", iph, minute), stmt(env2, "DELETE FROM attempts WHERE minute<?", minute - 10)]);
  if (rate[1].results[0].count > 10) fail("Troppi tentativi. Riprova tra un minuto.", 429);
  const b = await body(req), password = String(b.password || "");
  if (password.length > 128) fail("Email o password non corrette.", 403);
  const actual = await digest(password), expected = await digest(env2.ADMIN_PASSWORD);
  if (!same(actual, expected) || String(b.email || "").trim().toLowerCase() !== env2.ADMIN_EMAIL.toLowerCase()) fail("Email o password non corrette.", 403);
  await stmt(env2, ADMIN_TABLE).run();
  const secret = token(), actor = env2.ADMIN_EMAIL.toLowerCase();
  await env2.DB.batch([stmt(env2, "DELETE FROM admin_sessions WHERE expires<? OR revoked=1", t), stmt(env2, "INSERT INTO admin_sessions VALUES(?,?,?,?,?,0)", await digest(secret), actor, await digest("admin-v1:" + env2.ADMIN_PASSWORD), t, t + 8 * 3600)]);
  await audit(env2, actor, "accesso pannello", "amministratore");
  const r = json({ ok: true });
  r.headers.append("Set-Cookie", cookie("__Host-ar-admin", secret, 8 * 3600));
  return r;
}
__name(adminLogin, "adminLogin");
var ADMIN_LOGIN_HTML = `<!doctype html><html lang="it"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Accedi al pannello \xB7 Armonizza</title><style>body{font:17px system-ui;background:#f7f7f7;color:#161616;display:grid;place-items:center;min-height:95vh;margin:0}main{background:white;padding:32px;border-radius:16px;width:min(370px,80vw)}label{display:block;margin:15px 0}input,button{box-sizing:border-box;width:100%;font:inherit;padding:12px;border:1px solid #aaa;border-radius:8px}button{background:#cbe9fa;cursor:pointer}p{line-height:1.5}</style><main><h1>Pannello privato</h1><p>Accedi per gestire le key.</p><form><label>Email<input type="email" id="email" autocomplete="username" required></label><label>Password<input type="password" id="password" autocomplete="current-password" required maxlength="128"></label><button>Accedi</button></form><p id="message" role="status"></p></main><script>document.querySelector('form').onsubmit=async e=>{e.preventDefault();const button=document.querySelector('button');button.disabled=true;try{const r=await fetch('/api/admin/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:document.querySelector('#email').value,password:document.querySelector('#password').value})});const d=await r.json();if(!r.ok)throw Error(d.error);location.replace('/')}catch(e){document.querySelector('#message').textContent=e.message}finally{button.disabled=false}};<\/script></html>`;
async function audit(env2, actor, action, target) {
  await stmt(env2, "INSERT INTO audit VALUES(?,?,?,?,?)", crypto.randomUUID(), actor, action, target, now()).run();
}
__name(audit, "audit");
async function adminAPI(req, env2, actor) {
  const path = new URL(req.url).pathname;
  if (req.method === "GET" && path === "/api/admin/keys") {
    const licenses = (await stmt(env2, "SELECT id,label,enabled,expires,max_devices,max_sessions,ip_mode,allowed_ip,device_mode,allowed_device,created FROM licenses ORDER BY created DESC").all()).results;
    const devices = (await stmt(env2, "SELECT id,key_id,label,enabled,created FROM devices ORDER BY created DESC").all()).results;
    const sessions = (await stmt(env2, "SELECT id,key_id,device_id,ip,ua,created,seen,expires,revoked FROM sessions ORDER BY seen DESC LIMIT 2000").all()).results;
    const ips = (await stmt(env2, "SELECT * FROM ip_history ORDER BY last_seen DESC LIMIT 4000").all()).results;
    return json({ licenses, devices, sessions, ips, actor, server_time: now() });
  }
  if (req.method === "GET" && path === "/api/admin/audit") return json((await stmt(env2, "SELECT * FROM audit ORDER BY created DESC LIMIT 200").all()).results);
  if (req.method !== "POST") fail("Operazione non disponibile.", 404);
  origin(req);
  const b = await body(req);
  if (path === "/api/admin/keys") {
    const o = options(b);
    if (o.device_mode === "fixed") fail("Crea la key con primo dispositivo, poi scegli un dispositivo registrato.");
    const id2 = crypto.randomUUID(), key = "AR-" + token();
    await stmt(env2, "INSERT INTO licenses VALUES(?,?,?,?,?,?,?,?,?,?,?,?)", id2, await digest(key), ...Object.values(o), now()).run();
    await audit(env2, actor, "crea key", id2);
    return json({ id: id2, key }, 201);
  }
  const m = path.match(/^\/api\/admin\/keys\/([a-f0-9-]{36})\/(update|revoke-all|keep-session|keep-device|revoke-session|revoke-device|approve-device|delete)$/);
  if (!m) fail("Operazione non disponibile.", 404);
  const [, id, action] = m;
  if (!await stmt(env2, "SELECT id FROM licenses WHERE id=?", id).first()) fail("Key inesistente.", 404);
  if (action === "update") {
    const o = options(b), previous = await stmt(env2, "SELECT * FROM licenses WHERE id=?", id).first();
    if (o.ip_mode === "first" && previous.ip_mode === "first") o.allowed_ip = previous.allowed_ip;
    if (o.device_mode === "first" && previous.device_mode === "first") o.allowed_device = previous.allowed_device;
    if (o.allowed_device && !await stmt(env2, "SELECT id FROM devices WHERE id=? AND key_id=? AND enabled=1", o.allowed_device, id).first()) fail("Dispositivo non autorizzabile.");
    await stmt(env2, "UPDATE licenses SET label=?,enabled=?,expires=?,max_devices=?,max_sessions=?,ip_mode=?,allowed_ip=?,device_mode=?,allowed_device=? WHERE id=?", ...Object.values(o), id).run();
  }
  if (action === "delete") {
    if (b.confirm !== true) fail("Conferma l\u2019eliminazione definitiva della key.");
    await env2.DB.batch([stmt(env2, "DELETE FROM ip_history WHERE session_id IN (SELECT id FROM sessions WHERE key_id=?)", id), stmt(env2, "DELETE FROM omr_jobs WHERE key_id=?", id), stmt(env2, "DELETE FROM sessions WHERE key_id=?", id), stmt(env2, "DELETE FROM devices WHERE key_id=?", id), stmt(env2, "DELETE FROM licenses WHERE id=?", id)]);
  }
  if (action === "revoke-all") await stmt(env2, "UPDATE sessions SET revoked=1 WHERE key_id=?", id).run();
  if (["keep-session", "revoke-session"].includes(action)) {
    if (!await stmt(env2, "SELECT id FROM sessions WHERE id=? AND key_id=?", b.session, id).first()) fail("Sessione inesistente.");
    await stmt(env2, `UPDATE sessions SET revoked=1 WHERE key_id=? AND id${action === "keep-session" ? "!=" : "="}?`, id, b.session).run();
  }
  if (action === "approve-device") {
    const d = await stmt(env2, "SELECT enabled FROM devices WHERE id=? AND key_id=?", b.device, id).first();
    if (!d) fail("Dispositivo inesistente.");
    const count3 = await stmt(env2, "SELECT COUNT(*) AS n FROM devices WHERE key_id=? AND enabled=1", id).first(), license = await stmt(env2, "SELECT max_devices FROM licenses WHERE id=?", id).first();
    if (!d.enabled && count3.n >= license.max_devices) fail("Limite dispositivi raggiunto. Revoca prima un altro dispositivo.");
    await stmt(env2, `UPDATE devices SET enabled=1 WHERE id=? AND key_id=? AND (enabled=1 OR (SELECT COUNT(*) FROM devices WHERE key_id=? AND enabled=1)<(SELECT max_devices FROM licenses WHERE id=?))`, b.device, id, id, id).run();
    if (!(await stmt(env2, "SELECT enabled FROM devices WHERE id=?", b.device).first()).enabled) fail("Limite dispositivi raggiunto.");
  }
  if (["keep-device", "revoke-device"].includes(action)) {
    if (!await stmt(env2, "SELECT id FROM devices WHERE id=? AND key_id=?", b.device, id).first()) fail("Dispositivo inesistente.");
    const op = action === "keep-device" ? "!=" : "=";
    await env2.DB.batch([stmt(env2, `UPDATE devices SET enabled=0 WHERE key_id=? AND id${op}?`, id, b.device), stmt(env2, `UPDATE sessions SET revoked=1 WHERE key_id=? AND device_id${op}?`, id, b.device)]);
  }
  await audit(env2, actor, action, id);
  return json({ ok: true });
}
__name(adminAPI, "adminAPI");
async function omr(req, env2, s) {
  if (!env2.OMR_URL) fail("Riconoscimento PDF/immagini non collegato. MuseScore e MusicXML funzionano gi\xE0. Per le scansioni configura OMR_URL e OMR_TOKEN sul server.", 503);
  const url = new URL(env2.OMR_URL);
  if (url.protocol !== "https:") fail("Configurazione OMR non valida.", 503);
  const q = new URL(req.url).searchParams, job = q.get("job");
  if (job && !await stmt(env2, "SELECT id FROM omr_jobs WHERE id=? AND key_id=?", job, s.key_id).first()) fail("Importazione non autorizzata.", 403);
  for (const [k, v] of q) if (["job", "result", "health"].includes(k)) url.searchParams.set(k, v);
  const headers = new Headers();
  if (env2.OMR_TOKEN) headers.set("Authorization", "Bearer " + env2.OMR_TOKEN);
  for (const h of ["content-type", "x-file-name"]) if (req.headers.has(h)) headers.set(h, req.headers.get(h));
  let data;
  if (req.method === "POST") {
    if (Number(req.headers.get("content-length")) > 4e6) fail("File massimo 4 MB.", 413);
    data = await bounded(req, 4e6);
  } else if (!["GET", "DELETE"].includes(req.method)) fail("Metodo non valido.", 405);
  const r = await fetch(url, { method: req.method, headers, body: data, redirect: "error" });
  if (req.method === "POST" && r.ok) {
    const result = await r.clone().json();
    if (!/^[a-f0-9]{32}$/.test(result.id || "")) fail("Risposta OMR non valida.", 502);
    await stmt(env2, "INSERT INTO omr_jobs VALUES(?,?,?)", result.id, s.key_id, now()).run();
  }
  return new Response(r.body, { status: r.status, headers: { "Content-Type": r.headers.get("content-type") || "application/json" } });
}
__name(omr, "omr");
var LOGIN_HTML = `<!doctype html><html lang="it"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Accedi \xB7 Armonizza</title><style>:root{color-scheme:only light}*{box-sizing:border-box}body{font:18px system-ui;background:#fff;color:#000;display:grid;place-items:center;min-height:100vh;margin:0;padding:24px}main{background:#fff;color:#000;padding:36px;border:1px solid #000;border-radius:16px;width:min(100%,440px)}h1{margin-top:0}p{line-height:1.5}label{display:block;margin-top:24px}input,button{width:100%;font:inherit;padding:14px;margin:10px 0;border:1px solid #000;border-radius:8px}input{background:#fff;color:#000;caret-color:#000}input::placeholder{color:#000;opacity:1}input:focus-visible,button:focus-visible{outline:2px solid #000;outline-offset:3px}input:-webkit-autofill{-webkit-box-shadow:0 0 0 1000px #fff inset;-webkit-text-fill-color:#000}button{background:#000;color:#fff;cursor:pointer}button:disabled{background:#000;color:#fff;opacity:1;cursor:wait}::selection{background:#000;color:#fff}.small{font-size:14px}#message{min-height:24px;margin-bottom:0}</style><main><h1>Armonizza basso</h1><p>Inserisci la tua key per accedere.</p><form id="login"><label for="key">Key di accesso</label><input id="key" aria-label="Key di accesso" autocomplete="off" autocapitalize="off" spellcheck="false" required><button>Accedi</button></form><p class="small">L\u2019accesso viene ricordato su questo browser. La key resta soggetta ai limiti e alle autorizzazioni del proprietario.</p><p id="message" role="status"></p></main><script>document.querySelector('form').onsubmit=async e=>{e.preventDefault();const button=document.querySelector('button');button.disabled=true;try{const r=await fetch('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key:document.querySelector('input').value})});const d=await r.json();if(!r.ok)throw Error(d.error);location.replace('/')}catch(e){document.querySelector('#message').textContent=e.message}finally{button.disabled=false}};<\/script></html>`;
function protect(r) {
  const h = new Headers(r.headers);
  h.set("Cache-Control", "private, no-store");
  h.set("X-Content-Type-Options", "nosniff");
  h.set("Referrer-Policy", "same-origin");
  h.set("X-Frame-Options", "DENY");
  h.set("Content-Security-Policy", "frame-ancestors 'none'; object-src 'none'; base-uri 'self'");
  return new Response(r.body, { status: r.status, headers: h });
}
__name(protect, "protect");
function remembered(req, r, s) {
  if (s?.refreshCookies) {
    const c = cookies(req);
    r.headers.append("Set-Cookie", cookie("__Host-ar-session", c["__Host-ar-session"], REMEMBER_SECONDS));
    r.headers.append("Set-Cookie", cookie("__Host-ar-device", c["__Host-ar-device"], REMEMBER_SECONDS));
  }
  return protect(r);
}
__name(remembered, "remembered");
var worker_default = { async fetch(req, env2) {
  try {
    if (!env2.DB) fail("Database non configurato.", 503);
    const url = new URL(req.url);
    if (env2.APP_MODE === "admin") {
      if (url.pathname === "/login" && req.method === "GET") return protect(new Response(ADMIN_LOGIN_HTML, { headers: { "Content-Type": "text/html; charset=utf-8" } }));
      if (url.pathname === "/api/admin/login" && req.method === "POST") return protect(await adminLogin(req, env2));
      const actor = await adminIdentity(req, env2);
      if (!actor) return protect(url.pathname.startsWith("/api/") ? json({ error: "Accedi al pannello con email e password." }, 401) : new Response(null, { status: 302, headers: { Location: "/login" } }));
      if (url.pathname === "/api/admin/logout" && req.method === "POST") {
        origin(req);
        await stmt(env2, "UPDATE admin_sessions SET revoked=1 WHERE hash=?", await digest(cookies(req)["__Host-ar-admin"])).run();
        const r = json({ ok: true });
        r.headers.append("Set-Cookie", cookie("__Host-ar-admin", "", 0));
        return protect(r);
      }
      if (url.pathname === "/api/admin/session" && req.method === "GET") return protect(json({ ok: true, actor }));
      if (url.pathname.startsWith("/api/")) return protect(await adminAPI(req, env2, actor));
      return protect(await env2.ASSETS.fetch(req));
    }
    if (env2.APP_MODE !== "music") fail("APP_MODE non configurato.", 503);
    if (url.pathname === "/login" && req.method === "GET") {
      const current = await validateSession(req, env2);
      if (current) return remembered(req, new Response(null, { status: 302, headers: { Location: "/" } }), current);
      return protect(new Response(LOGIN_HTML, { headers: { "Content-Type": "text/html; charset=utf-8" } }));
    }
    if (url.pathname === "/api/auth/login" && req.method === "POST") return protect(await login(req, env2));
    const session = await validateSession(req, env2);
    if (!session) {
      if (url.pathname.startsWith("/api/")) return protect(json({ error: "Accesso scaduto o revocato. Inserisci la key." }, 401));
      return protect(new Response(null, { status: 302, headers: { Location: "/login" } }));
    }
    if (url.pathname === "/api/auth/session") return remembered(req, json({ ok: true, key: session.key_id, device: session.device_id, expires: session.expires }), session);
    if (url.pathname === "/api/auth/logout" && req.method === "POST") {
      origin(req);
      await stmt(env2, "UPDATE sessions SET revoked=1 WHERE id=?", session.id).run();
      const r = json({ ok: true });
      r.headers.append("Set-Cookie", cookie("__Host-ar-session", "", 0));
      return protect(r);
    }
    if (url.pathname === "/api/omr") {
      if (req.method !== "GET") origin(req);
      return remembered(req, await omr(req, env2, session), session);
    }
    if (url.pathname.startsWith("/api/")) return protect(json({ error: "Non trovato." }, 404));
    return remembered(req, await env2.ASSETS.fetch(req), session);
  } catch (e) {
    return protect(json({ error: e.status ? e.message : "Errore del server. Verifica configurazione e database." }, e.status || 500));
  }
} };
export {
  ADMIN_LOGIN_HTML,
  LOGIN_HTML,
  REMEMBER_SECONDS,
  adminAPI,
  adminIdentity,
  adminLogin,
  worker_default as default,
  digest,
  login,
  normalizeIP,
  options,
  validateSession
};
//# sourceMappingURL=bundledWorker-0.3426405583150647.mjs.map
