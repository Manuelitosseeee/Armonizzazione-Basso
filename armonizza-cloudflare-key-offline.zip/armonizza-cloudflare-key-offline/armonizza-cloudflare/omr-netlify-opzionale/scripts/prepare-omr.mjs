// Eseguito durante la build Netlify. Il runtime non entra nel sito pubblico.
import fs from 'node:fs/promises';import path from 'node:path';import{spawn}from'node:child_process';import{createHash}from'node:crypto';import{Readable}from'node:stream';import{pipeline}from'node:stream/promises';import{createWriteStream}from'node:fs';
const root=path.resolve(import.meta.dirname,'..'),cache=path.join(root,'.cache/omr'),out=path.join(root,'netlify/runtime'),version='5.10.2',digest='9470d15e79dd4fe45f817b8545ba9f8e57ddaebff3b3a1031f21218647602068';
export const run=(cmd,args)=>new Promise((resolve,reject)=>{const p=spawn(cmd,args,{stdio:'inherit'});p.on('error',reject);p.on('exit',code=>code===0?resolve():reject(Error(`${cmd}: ${code}`)))});
async function download(url,file){const r=await fetch(url,{signal:AbortSignal.timeout(180000)});if(!r.ok)throw Error(`Download ${r.status}: ${url}`);await pipeline(Readable.fromWeb(r.body),createWriteStream(file));}
export async function prepare(){
 if(process.platform!=='linux'||process.arch!=='x64')throw Error('La build OMR richiede Linux x86_64: viene eseguita automaticamente da Netlify.');
 await fs.mkdir(cache,{recursive:true});await fs.mkdir(out,{recursive:true});const deb=path.join(cache,'audiveris.deb');
 try{await fs.access(deb)}catch{await download(`https://github.com/Audiveris/audiveris/releases/download/${version}/Audiveris-${version}-ubuntu22.04-x86_64.deb`,deb)}
 if(createHash('sha256').update(await fs.readFile(deb)).digest('hex')!==digest)throw Error('Checksum Audiveris non valido. Elimina .cache/omr e ripeti la build.');
 const extracted=path.join(cache,'extracted');await run('dpkg-deb',['-x',deb,extracted]);
 const base=path.join(extracted,'opt/audiveris/lib'),stage=path.join(cache,'stage');await fs.rm(stage,{recursive:true,force:true});await fs.mkdir(path.join(stage,'app'),{recursive:true});
 for(const name of await fs.readdir(path.join(base,'app')))if(name.endsWith('.jar'))await fs.copyFile(path.join(base,'app',name),path.join(stage,'app',name));
 await fs.cp(path.join(base,'runtime'),path.join(stage,'jre'),{recursive:true,dereference:true});
 // Un solo insieme di native Linux x64; gli altri OS non servono nella Lambda.
 for(const name of await fs.readdir(path.join(stage,'app')))if(/-(linux-arm64|windows[^.]*|macosx[^.]*)\.jar$/.test(name))await fs.unlink(path.join(stage,'app',name));
 await fs.mkdir(path.join(stage,'fonts'),{recursive:true});
 let fonts=0;for(const name of ['DejaVuSans.ttf','DejaVuSans-Bold.ttf','DejaVuSerif.ttf']){
  const local='/usr/share/fonts/truetype/dejavu/'+name;try{await fs.copyFile(local,path.join(stage,'fonts',name));fonts++}catch{}
 }
 if(!fonts){
  const fontZip=path.join(cache,'fonts.zip');await download('https://github.com/dejavu-fonts/dejavu-fonts/releases/download/version_2_37/dejavu-fonts-ttf-2.37.zip',fontZip);await run('unzip',['-o','-q',fontZip,'*/ttf/*.ttf','-d',path.join(cache,'fonts')]);
  const ttf=path.join(cache,'fonts/dejavu-fonts-ttf-2.37/ttf');for(const name of ['DejaVuSans.ttf','DejaVuSans-Bold.ttf','DejaVuSerif.ttf'])await fs.copyFile(path.join(ttf,name),path.join(stage,'fonts',name));
 }
 // Fontconfig assente in alcune immagini Lambda: librerie Linux compatibili allegate.
 await fs.mkdir(path.join(stage,'native'),{recursive:true});
 for(const [name,url]of [
 ['fontconfig.deb','https://archive.ubuntu.com/ubuntu/pool/main/f/fontconfig/libfontconfig1_2.13.1-4.2ubuntu5_amd64.deb'],
 ['expat.deb','https://archive.ubuntu.com/ubuntu/pool/main/e/expat/libexpat1_2.4.7-1ubuntu0.9_amd64.deb'],
 ['freetype.deb','https://archive.ubuntu.com/ubuntu/pool/main/f/freetype/libfreetype6_2.11.1+dfsg-1ubuntu0.3_amd64.deb'],
 ['png.deb','https://archive.ubuntu.com/ubuntu/pool/main/libp/libpng1.6/libpng16-16_1.6.37-3ubuntu0.6_amd64.deb'],
 ['brotli.deb','https://archive.ubuntu.com/ubuntu/pool/main/b/brotli/libbrotli1_1.0.9-2build6_amd64.deb']]){
  const file=path.join(cache,name);try{await fs.access(file)}catch{await download(url,file)}await run('dpkg-deb',['-x',file,path.join(cache,'native')]);
 }
 for(const directory of ['usr/lib/x86_64-linux-gnu','lib/x86_64-linux-gnu']){try{for(const name of await fs.readdir(path.join(cache,'native',directory)))if(/^lib(fontconfig|expat|freetype|png16|brotli\w*)\.so/.test(name))await fs.copyFile(path.join(cache,'native',directory,name),path.join(stage,'native',name))}catch(error){if(error.code!=='ENOENT')throw error}}
 
 const bytes=async directory=>{let sum=0;for(const name of await fs.readdir(directory)){const p=path.join(directory,name),s=await fs.stat(p);sum+=s.isDirectory()?await bytes(p):s.size}return sum};const unpacked=await bytes(stage);if(unpacked>210_000_000)throw Error('Runtime oltre il budget di distribuzione.');
 await fs.writeFile(path.join(stage,'manifest.json'),JSON.stringify({version,unpackedBytes:unpacked,sha256:digest}));
 await run('tar',['-czf',path.join(out,'audiveris.tar.gz'),'-C',stage,'.']);await fs.writeFile(path.join(out,'manifest.json'),JSON.stringify({version,unpackedBytes:unpacked,sha256:digest}));console.log(`Runtime OMR ${version}: ${(unpacked/1048576).toFixed(1)} MiB, avvio solo su importazione.`);
}
if(process.argv[1]===import.meta.filename)await prepare();
