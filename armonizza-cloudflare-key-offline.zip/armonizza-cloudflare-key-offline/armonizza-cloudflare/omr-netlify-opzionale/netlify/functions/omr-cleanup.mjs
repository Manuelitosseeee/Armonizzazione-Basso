import{getStore}from'@netlify/blobs';import{cleanup}from'../omr/jobs.mjs';
export default async()=>{await cleanup(getStore({name:'armonizza-omr',consistency:'strong'}));return new Response('OK')};
export const config={schedule:'17 3 * * *'};
