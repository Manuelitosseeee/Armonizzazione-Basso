import{getStore,getDeployStore}from'@netlify/blobs';import{work}from'../omr/jobs.mjs';import{recognize}from'../omr/audiveris.mjs';
export default async request=>{let payload;try{payload=await request.json()}catch{return}await work(payload,{store:getStore({name:'armonizza-omr',consistency:'strong'}),recognize:(bytes,options)=>recognize(bytes,{...options,getArchive:()=>getDeployStore('armonizza-runtime').get('audiveris-5.10.2',{type:'arrayBuffer'})})})};
export const config={background:true};
