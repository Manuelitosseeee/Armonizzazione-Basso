import{getStore}from'@netlify/blobs';import{handle}from'../omr/jobs.mjs';
export default async function(request){
 const required=process.env.OMR_PROXY_TOKEN;
 if(required && request.headers.get('Authorization')!=='Bearer '+required)return new Response(JSON.stringify({error:'Accesso al motore non autorizzato.'}),{status:401,headers:{'Content-Type':'application/json'}});

 try{return await handle(request,{store:getStore({name:'armonizza-omr',consistency:'strong'}),limit:process.env.OMR_DAILY_LIMIT,start:async payload=>{
  const url=new URL('/.netlify/functions/recognize-background',request.url);const response=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),signal:AbortSignal.timeout(10000)});if(response.status!==202)throw Error('Background non disponibile');
 }})}catch{return new Response(JSON.stringify({error:'Il riconoscimento Netlify non è disponibile. Verifica il deploy con build e l’attivazione di Blobs.'}),{status:503,headers:{'Content-Type':'application/json','Cache-Control':'no-store'}})}
}
