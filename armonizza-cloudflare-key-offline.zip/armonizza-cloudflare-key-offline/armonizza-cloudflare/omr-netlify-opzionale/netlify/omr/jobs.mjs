import{randomBytes,timingSafeEqual}from'node:crypto';
export const MAX_BYTES=4_000_000,TTL=24*3600_000,DEADLINE=12*60_000;
export const idValid=id=>/^[a-f0-9]{32}$/.test(id||'');
export function signature(data){const b=Buffer.from(data);if(b.subarray(0,5).toString()==='%PDF-')return 'pdf';if(b.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))return 'png';if(b[0]===255&&b[1]===216&&b[2]===255)return 'jpg';if(b.subarray(0,4).toString()==='RIFF'&&b.subarray(8,12).toString()==='WEBP')return 'webp';if(b.subarray(0,2).toString()==='BM')return 'bmp';if(b.subarray(0,4).equals(Buffer.from([73,73,42,0]))||b.subarray(0,4).equals(Buffer.from([77,77,0,42])))return 'tif';throw Error('Il file non è un PDF o un’immagine supportata.');}
const json=(status,value)=>new Response(JSON.stringify(value),{status,headers:{'Content-Type':'application/json','Cache-Control':'no-store'}});
const terminal=s=>['done','error','cancelled'].includes(s);
export async function update(store,id,change){for(let n=0;n<5;n++){const record=await store.getWithMetadata('job/'+id,{type:'json'});if(!record)return null;const value=change(record.data);if(!value)return record.data;const r=await store.setJSON('job/'+id,value,{onlyIfMatch:record.etag});if(r.modified)return value}throw Error('Aggiornamento concorrente: riprova.');}
async function lease(store,id,now){for(let i=0;i<2;i++){const key='slot/'+i,previous=await store.getWithMetadata(key,{type:'json'});if(previous&&previous.data.until>now)continue;const r=await store.setJSON(key,{id,until:now+DEADLINE+60_000},previous?{onlyIfMatch:previous.etag}:{onlyIfNew:true});if(r.modified)return key}return null;}
export async function release(store,slot,id){if(!slot)return;const r=await store.getWithMetadata(slot,{type:'json'});if(r?.data.id===id)await store.setJSON(slot,{id:'',until:0},{onlyIfMatch:r.etag});}
async function budget(store,now,limit){const key='budget/'+new Date(now).toISOString().slice(0,10);for(let i=0;i<6;i++){const r=await store.getWithMetadata(key,{type:'json'});if((r?.data.count||0)>=limit)return false;const saved=await store.setJSON(key,{count:(r?.data.count||0)+1,created:now},r?{onlyIfMatch:r.etag}:{onlyIfNew:true});if(saved.modified)return true}return false;}
async function handleInternal(request,{store,start,now=Date.now(),limit=50}={}){
 const url=new URL(request.url),id=url.searchParams.get('job');
 if(!['GET','POST','DELETE'].includes(request.method))return json(405,{error:'Metodo non ammesso.'});
 if(request.method==='GET'&&url.searchParams.has('health'))return json(200,{available:true,engine:'Audiveris 5.10.2 su Netlify',maxBytes:MAX_BYTES,onDemand:true});
 if(request.method==='POST'){
  const origin=request.headers.get('origin');if(origin&&!originAllowed(origin,url.origin))return json(403,{error:'Carica la partitura dal sito.'});
  if(Number(request.headers.get('content-length'))>MAX_BYTES)return json(413,{error:'File oltre 4 MB.'});
  const data=await request.arrayBuffer();if(!data.byteLength||data.byteLength>MAX_BYTES)return json(413,{error:'File vuoto o oltre 4 MB.'});
  let kind;try{kind=signature(data)}catch(error){return json(400,{error:error.message})}
  const identifier=randomBytes(16).toString('hex'),slot=await lease(store,identifier,now);if(!slot)return json(429,{error:'Ci sono già due riconoscimenti in corso. Riprova fra poco.'});
  try{
   if(!await budget(store,now,Math.max(1,Math.min(500,Number(limit)||50)))){await release(store,slot,identifier);return json(429,{error:'Limite giornaliero di importazioni raggiunto. Riprova domani.'})}
   const secret=randomBytes(24).toString('hex');await store.set('input/'+identifier,data);await store.setJSON('job/'+identifier,{id:identifier,status:'queued',message:'Partitura in attesa…',kind,created:now,expires:now+TTL,slot,secret});
   await start({id:identifier,secret},url.origin);
   return json(202,{id:identifier});
  }catch{
   await Promise.allSettled([store.delete('input/'+identifier),store.delete('job/'+identifier),release(store,slot,identifier)]);return json(503,{error:'Non riesco ad avviare il riconoscimento su Netlify. Controlla il deploy delle funzioni.'});
  }
 }
 if(!idValid(id))return json(400,{error:'Identificativo non valido.'});
 let job=await store.get('job/'+id,{type:'json'});if(!job)return json(404,{error:'Riconoscimento non trovato o scaduto. Ricarica il file.'});
 if(job.expires<=now){await Promise.allSettled(['input/','output/','job/'].map(p=>store.delete(p+id)));await release(store,job.slot,id);return json(410,{error:'Risultato scaduto. Ricarica il file.'})}
 if(!terminal(job.status)&&now-job.created>DEADLINE){job=await update(store,id,j=>terminal(j.status)?null:{...j,status:'error',message:'Il riconoscimento ha superato il tempo disponibile. Prova meno pagine o una foto più nitida.'});await release(store,job.slot,id)}
 if(request.method==='DELETE'){
  await update(store,id,j=>terminal(j.status)?null:{...j,status:'cancelled',message:'Riconoscimento annullato.'});await store.delete('input/'+id);if(job.status==='queued')await release(store,job.slot,id);return json(200,{});
 }
 if(url.searchParams.get('result')==='1'){
  if(job.status!=='done')return json(409,{error:'Risultato non ancora pronto.'});const output=await store.get('output/'+id,{type:'arrayBuffer'});if(!output)return json(410,{error:'Risultato scaduto. Ricarica il file.'});
  return new Response(output,{headers:{'Content-Type':'application/vnd.recordare.musicxml','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
 }
 return json(200,{status:job.status,message:job.message,warnings:job.warnings||[]});
}
export async function work({id,secret},{store,recognize,now=Date.now}={}){
 if(!idValid(id)||typeof secret!=='string')return;
 const original=await store.getWithMetadata('job/'+id,{type:'json'});if(!original||original.data.status!=='queued')return;
 const expected=Buffer.from(original.data.secret),given=Buffer.from(secret);if(given.length!==expected.length||!timingSafeEqual(given,expected))return;
 if(now()-original.data.created>DEADLINE){await update(store,id,j=>j.status==='queued'?{...j,status:'error',message:'Il riconoscimento non è partito in tempo. Ricarica il file.'}:null);await store.delete('input/'+id);await release(store,original.data.slot,id);return}
 const claimed=await store.setJSON('job/'+id,{...original.data,status:'running',message:'Leggo righi, note, alterazioni e ritmi…',started:now()},{onlyIfMatch:original.etag});if(!claimed.modified)return;
 const control=new AbortController();let polling=false;
 const check=async()=>{if(polling)return;polling=true;try{const j=await store.get('job/'+id,{type:'json'});if(!j||j.status!=='running'||now()-j.created>DEADLINE)control.abort()}catch{}finally{polling=false}};
 const timer=setInterval(check,4000);timer.unref?.();
 try{
  const input=await store.get('input/'+id,{type:'arrayBuffer'});if(!input)throw Error('Il file da riconoscere non è più disponibile.');
  const result=await recognize(Buffer.from(input),{kind:original.data.kind,signal:control.signal});
  const current=await store.get('job/'+id,{type:'json'});if(current?.status!=='running')return;
  if(!result.bytes?.length||result.bytes.length>MAX_BYTES)throw Error('Risultato troppo grande o vuoto. Importa meno pagine.');
  await store.set('output/'+id,result.bytes);
  const saved=await update(store,id,j=>j.status==='running'?{...j,status:'done',message:'Note riconosciute. Controlla l’anteprima.',warnings:result.warnings||[]}:null);if(saved?.status!=='done')await store.delete('output/'+id);
 }catch(error){console.error('OMR worker error',{message:error.message,code:error.code||error.cause?.code,detail:error.cause?.message,engineLog:error.engineLog});await update(store,id,j=>j.status==='running'?{...j,status:'error',message:control.signal.aborted?'Riconoscimento interrotto. Riprova con meno pagine.':error.publicMessage||'Audiveris non ha completato il riconoscimento. Prova una scansione più nitida o meno pagine.'}:null)}
 finally{clearInterval(timer);await store.delete('input/'+id);await release(store,original.data.slot,id)}
}
export async function cleanup(store,now=Date.now()){
 const listed=await store.list({prefix:'job/'});let removed=0;for(const b of listed.blobs){const j=await store.get(b.key,{type:'json'});if(j&&j.expires<=now){await Promise.allSettled(['input/','output/','job/'].map(p=>store.delete(p+j.id)));await release(store,j.slot,j.id);removed++}}
 const budgets=await store.list({prefix:'budget/'});for(const b of budgets.blobs){const v=await store.get(b.key,{type:'json'});if(v&&now-v.created>3*24*3600_000)await store.delete(b.key)}return removed;
}

export function originAllowed(origin,own){return !origin||origin===own||origin==='https://armonizza-basso.manuelonthewebs.chatgpt.site'||(process.env.OMR_ALLOWED_ORIGINS||'').split(',').map(s=>s.trim()).includes(origin)}
export async function handle(request,options){
 const origin=request.headers.get('origin'),own=new URL(request.url).origin;
 if(!originAllowed(origin,own))return json(403,{error:'Origine del sito non autorizzata.'});
 const response=request.method==='OPTIONS'?new Response(null,{status:204}):await handleInternal(request,options);
 if(origin){response.headers.set('Access-Control-Allow-Origin',origin);response.headers.set('Vary','Origin');response.headers.set('Access-Control-Allow-Methods','GET, POST, DELETE, OPTIONS');response.headers.set('Access-Control-Allow-Headers','Content-Type, X-File-Name');response.headers.set('Access-Control-Max-Age','600')}
 return response;
}
