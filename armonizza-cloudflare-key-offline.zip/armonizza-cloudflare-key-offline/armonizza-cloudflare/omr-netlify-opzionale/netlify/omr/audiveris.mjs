import fs from'node:fs/promises';import path from'node:path';import os from'node:os';import{spawn}from'node:child_process';import sharp from'sharp';import{extract}from'tar';import{signature}from'./jobs.mjs';
let ready;
const publicError=message=>Object.assign(Error(message),{publicMessage:message});
export async function runtime(archive=process.env.OMR_RUNTIME_ARCHIVE,getArchive){
 if(process.env.OMR_RUNTIME_DIR)return process.env.OMR_RUNTIME_DIR;
 if(!ready)ready=(async()=>{
  const target=await fs.mkdtemp(path.join(os.tmpdir(),'audiveris-runtime-'));
  try{
   if(getArchive){let data;try{data=await getArchive()}catch(cause){throw Object.assign(publicError('Non riesco a caricare il motore da Netlify Blobs (OMR_STORAGE). Ripeti la build del sito.'),{cause})}
    if(!data)throw publicError('Runtime di riconoscimento non pubblicato (OMR_MISSING). Ripeti la build Netlify.');
    archive=path.join(target,'runtime.tar.gz');await fs.writeFile(archive,new Uint8Array(data));
   }
   if(!archive)throw publicError('Runtime di riconoscimento non pubblicato (OMR_MISSING). Ripeti la build Netlify.');
   try{await extract({file:archive,cwd:target,strict:true,preservePaths:false})}catch(cause){throw Object.assign(publicError('Non riesco a estrarre il motore di riconoscimento (OMR_EXTRACT). Ripeti la build Netlify.'),{cause})}
   if(getArchive)await fs.unlink(archive);
   await fs.chmod(path.join(target,'jre/bin/java'),0o755);return target;
  }catch(e){await fs.rm(target,{recursive:true,force:true,maxRetries:3,retryDelay:50}).catch(()=>{});throw e}
 })().catch(e=>{ready=null;throw e});return ready;
}
export async function prepareInput(bytes,folder){
 const kind=signature(bytes);if(kind==='pdf'){const file=path.join(folder,'scan.pdf');await fs.writeFile(file,bytes);return file}
 const image=sharp(bytes,{limitInputPixels:24_000_000}),meta=await image.metadata();if((meta.pages||1)>1)throw publicError('TIFF multipagina: converti in PDF per conservare tutte le pagine.');
 let pipeline=image.rotate().flatten({background:'#fff'}).greyscale();if(meta.width<1600){const factor=Math.min(3,2400/meta.width,Math.sqrt(24_000_000/(meta.width*meta.height)));pipeline=pipeline.resize({width:Math.round(meta.width*factor)})}
 const file=path.join(folder,'scan.png');await pipeline.png().toFile(file);return file;
}
async function files(dir){const result=[];for(const name of await fs.readdir(dir)){const p=path.join(dir,name);if((await fs.stat(p)).isDirectory())result.push(...await files(p));else result.push(p)}return result}
export function engineFailure(log,signal){
 const message=/OutOfMemoryError|Cannot allocate memory|insufficient memory|Native memory allocation/i.test(log)?'Memoria insufficiente per questa scansione (OMR_MEMORY). Importa meno pagine.':
 /error while loading shared libraries|GLIBC_[\d.]+.*not found|UnsatisfiedLinkError|Fontconfig head is null|no fonts found/i.test(log)?'Una libreria del motore non è disponibile su Netlify (OMR_NATIVE). È un problema tecnico, non della scansione.':
 signal?'Riconoscimento interrotto o troppo lungo (OMR_TIMEOUT). Prova meno pagine.':'Audiveris si è interrotto durante la lettura (OMR_ENGINE). Controlla i log della funzione recognize-background.';
 const detail=log.split(/\r?\n/).find(line=>/^(?:Error:|Exception in thread|Caused by:)|(?:java\.[\w.]+(?:Exception|Error))|Could not|unable to|not found/i.test(line))?.replace(/(?:\/[\w.\-]+){2,}/g,'[percorso]').trim().slice(0,240);
 return Object.assign(publicError(message+(detail?' Dettaglio: '+detail:'')),{engineLog:log.slice(-4000)});
}
export async function recognize(bytes,{signal,root,heapMiB,getArchive}={}){
 if(signal?.aborted)throw publicError('Riconoscimento annullato.');
 const folder=await fs.mkdtemp(path.join(os.tmpdir(),'armonizza-job-'));let child;
 try{
  root||=await runtime(undefined,getArchive);const input=await prepareInput(bytes,folder),out=path.join(folder,'output');await fs.mkdir(out);await fs.mkdir(path.join(folder,'config'));await fs.mkdir(path.join(folder,'cache'));
  await fs.writeFile(path.join(folder,'fonts.conf'),`<?xml version="1.0"?><!DOCTYPE fontconfig SYSTEM "fonts.dtd"><fontconfig><dir>${root}/fonts</dir><cachedir>${folder}/cache</cachedir></fontconfig>`);
  const memory=Number(process.env.AWS_LAMBDA_FUNCTION_MEMORY_SIZE)||1024,heap=heapMiB||Math.max(384,Math.min(1536,Math.floor(memory*.55)));
  const args=['-XX:-UseContainerSupport','-XX:ActiveProcessorCount=2','-XX:+UseSerialGC','-Xms64m','--add-exports=java.desktop/sun.awt.image=ALL-UNNAMED','--enable-native-access=ALL-UNNAMED','-Djava.awt.headless=true',`-Djava.io.tmpdir=${folder}`,`-Duser.home=${folder}`,`-Dsun.java2d.fontpath=${root}/fonts`,`-Dorg.bytedeco.javacpp.cachedir=${folder}/cache`,`-Xmx${heap}m`,'-cp',`${root}/app/*`,'Audiveris','-batch','-export','-output',out,'--',input];
  const env={...process.env,LD_LIBRARY_PATH:[`${root}/native`,`${root}/jre/lib`,`${root}/jre/lib/server`,process.env.LD_LIBRARY_PATH||''].join(':'),XDG_CONFIG_HOME:folder+'/config',XDG_DATA_HOME:folder+'/data',FONTCONFIG_FILE:folder+'/fonts.conf',FONTCONFIG_PATH:folder};delete env.JAVA_TOOL_OPTIONS;delete env._JAVA_OPTIONS;
  let log='',head='',engineIssue=null,rhythmUncertain=false;await new Promise((resolve,reject)=>{
   child=spawn(path.join(root,'jre/bin/java'),args,{env,stdio:['ignore','pipe','pipe']});const record=b=>{const text=b.toString();if(/no correct rhythm|rhythm.*(?:error|invalid)/i.test(text))rhythmUncertain=true;if(head.length<6000)head=(head+text).slice(0,6000);log=(log+text).slice(-16000)};child.stdout.on('data',record);child.stderr.on('data',record);
   const kill=()=>child.kill('SIGKILL');signal?.addEventListener('abort',kill,{once:true});const timeout=setTimeout(kill,11*60_000);if(signal?.aborted)kill();
   const finish=()=>{clearTimeout(timeout);signal?.removeEventListener('abort',kill)};child.on('error',cause=>{finish();reject(Object.assign(publicError('Java non riesce ad avviarsi su Netlify (OMR_JAVA_START). È un problema del motore, non delle note.'),{cause}))});child.on('exit',(code,sig)=>{finish();if(code===0)resolve();else if(sig)reject(engineFailure(head+'\n'+log,sig));else{engineIssue=engineFailure(head+'\n'+log,null);resolve()}});
  });
  if(signal?.aborted)throw publicError('Riconoscimento annullato.');
  const results=(await files(out)).filter(p=>p.endsWith('.mxl')),exact=results.filter(p=>path.basename(p)==='scan.mxl');let chosen=exact.length===1?exact[0]:results.length===1?results[0]:null;
  if(!chosen&&engineIssue)throw engineIssue;
  if(!chosen)throw publicError(results.length?'Sono state riconosciute più partiture: importa un esercizio per volta.':'Non sono state riconosciute note esportabili. Prova una scansione più nitida con righi completi.');
  const warnings=rhythmUncertain?['Audiveris segnala battute con ritmo incerto: controlla durate e pause nell’anteprima.']:[];
  if(engineIssue)warnings.push('Audiveris ha esportato un risultato prima di segnalare un errore. Potrebbe essere incompleto: confronta tutte le battute con l’originale.');
  return{bytes:await fs.readFile(chosen),warnings};
 }catch(error){if(error.publicMessage)throw error;throw Object.assign(publicError(error.code==='ENOSPC'?'Spazio temporaneo esaurito (OMR_DISK). Riprova con meno pagine.':'Errore tecnico durante la preparazione del riconoscimento (OMR_PREPARE). Non è un errore di armonizzazione.'),{cause:error})}finally{if(child&&child.exitCode===null)child.kill('SIGKILL');await fs.rm(folder,{recursive:true,force:true})}
}
