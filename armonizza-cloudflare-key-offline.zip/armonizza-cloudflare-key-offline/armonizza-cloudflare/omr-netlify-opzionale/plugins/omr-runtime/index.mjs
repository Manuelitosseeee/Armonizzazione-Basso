import fs from'node:fs/promises';import path from'node:path';import{getDeployStore}from'@netlify/blobs';
async function publishRuntime(store,root=process.cwd()){
 const bytes=await fs.readFile(path.join(root,'netlify/runtime/audiveris.tar.gz'));if(bytes.length<1000)throw Error('Runtime OMR incompleto');
 await store.set('audiveris-5.10.2',bytes,{metadata:{version:'5.10.2'}});
}
export const onPostBuild=async()=>{await publishRuntime(getDeployStore('armonizza-runtime'));console.log('Runtime Audiveris pubblicato in Netlify Blobs. Avvio solo durante importazione.');};
