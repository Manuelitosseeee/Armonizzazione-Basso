@echo off
setlocal
cd /d "%~dp0"
node attiva-login.mjs
pause
endlocal
