@echo off
setlocal
cd /d "%~dp0"
node aggiorna-siti.mjs
if errorlevel 1 echo Aggiornamento non completato. Leggi l errore sopra.
pause
endlocal
