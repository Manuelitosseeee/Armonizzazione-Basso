@echo off
cd /d "%~dp0"
node configura.mjs
pause
